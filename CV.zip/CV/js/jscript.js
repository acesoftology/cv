$(document).ready(function(){
	$('#cvd').click(function(){
		alert('ashish');
	});
});